<?php
$conn = mysqli_connect('localhost','root','','e_drafting',3307);

if(!$conn){
    die('connection error'.mysqli_connect_error());
}

?>